theme: /

    state: ChooseSea
        q!: * (море | на море | пляж | пляжный) *
        event: CLICK_SEA
        script:
            $session.currentList = "sea";
            $session.items = ["Паспорт", "Купальник или плавки", "Солнцезащитный крем", "Солнцезащитные очки", "Шлепанцы"];
            
            $client.savedProgress = $client.savedProgress || {};
            
            var savedData = $client.savedProgress.sea || {};
            var activeIndex = savedData.currentIndex || 0;
            
            $session.currentIndex = activeIndex;
            $session.hasSkippedItems = savedData.hasSkippedItems || false;
            
            setChecklistAction($session.currentList, $session.items, $context);

            if ($session.currentIndex >= $session.items.length) {
                $reactions.transition("/ConfirmReset");
            }
            
        # ОТВЕТ: зависит от того, новый список или продолжение
        if: $session.currentIndex === 0
            a: Отлично, собираемся на море! Поехали. Паспорт с тобой?
        else:
            a: Рад возвращению! Продолжаем собираться на море. Мы остановились здесь: {{$session.items[$session.currentIndex]}} с тобой?


    state: ChooseMountains
        q!: * (горы | в горы | поход | альпинизм) *
        event: CLICK_MOUNTAINS
        script:
            $session.currentList = "mountains";
            $session.items = ["Паспорт", "Трекинговые ботинки", "Ветрозащитная куртка", "Фонарик", "Дождевик"];
            
            $client.savedProgress = $client.savedProgress || {};
            
            var savedData = $client.savedProgress.mountains || {};
            var activeIndex = savedData.currentIndex || 0;
            
            $session.currentIndex = activeIndex;
            $session.hasSkippedItems = savedData.hasSkippedItems || false;

            setChecklistAction($session.currentList, $session.items, $context);

            if ($session.currentIndex >= $session.items.length) {
                $reactions.transition("/ConfirmReset");
            }
            
        if: $session.currentIndex === 0
            a: Прекрасно, горы зовут! Давай проверим. Паспорт при себе?
        else:
            a: С возвращением к горным сборам! Нам осталось собрать еще немного. На очереди: {{$session.items[$session.currentIndex]}} при себе?


    state: ChooseBusiness
        q!: * (командировк* | в командировку | бизнес | работа) *
        event: CLICK_BUSINESS
        script:
            $session.currentList = "business";
            $session.items = ["Паспорт", "Ноутбук", "Зарядное устройство", "Деловая одежда", "Блокнот и ручка"];
            
            $client.savedProgress = $client.savedProgress || {};
            
            var savedData = $client.savedProgress.business || {};
            var activeIndex = savedData.currentIndex || 0;
            
            $session.currentIndex = activeIndex;
            $session.hasSkippedItems = savedData.hasSkippedItems || false;
            
            setChecklistAction($session.currentList, $session.items, $context);
            
            if ($session.currentIndex >= $session.items.length) {
                $reactions.transition("/ConfirmReset");
            }
            
        if: $session.currentIndex === 0
            a: Приступаем к сборам в деловую поездку. Начнём с документов. Паспорт на месте?
        else:
            a: Возвращаемся к деловым сборам. Напомню, мы остановились на этом: {{$session.items[$session.currentIndex]}} на месте?


    # --- Цикл голосового опроса ---

    state: ItemConfirmed
        q: * (да | положи* | взял* | готово | ага | добавил*) *
        event: CLICK_YES
        script:
            if ($session.items && $session.currentIndex < $session.items.length) {
                updateItemStatusAction($session.currentIndex, "completed", $context);
                $session.currentIndex++;

                # 👈 АВТОСОХРАНЕНИЕ ПРОГРЕССА В БАЗУ БЭКЕНДА
                $client.savedProgress = $client.savedProgress || {};
                $client.savedProgress[$session.currentList] = {
                    currentIndex: $session.currentIndex,
                    hasSkippedItems: $session.hasSkippedItems
                };
            }
        if: $session.currentIndex < $session.items.length
            random: 
                a: Принято. {{$session.items[$session.currentIndex]}} с тобой?
                a: Принято. {{$session.items[$session.currentIndex]}} на месте?
                a: Принято. {{$session.items[$session.currentIndex]}} при себе?
                a: Принято. {{$session.items[$session.currentIndex]}} в сумке?
        elseif: $session.hasSkippedItems
            a: Чеклист пройден! Но некоторые вещи мы пропустили. Проверь их на экране приложения.
        else:
            a: Ура! Все вещи из чеклиста успешно собраны. Счастливого пути!

    state: ItemSkipped
        q: * (пропусти | пропустить | позже | нет | пропуск | следующий | отложить) *
        event: CLICK_SKIP
        script:
            if ($session.items && $session.currentIndex < $session.items.length) {
                updateItemStatusAction($session.currentIndex, "skipped", $context);
                $session.hasSkippedItems = true; // Запоминаем, что в списке есть пропуски
                $session.currentIndex++;

                # АВТОСОХРАНЕНИЕ ПРОГРЕССА В БАЗУ БЭКЕНДА
                $client.savedProgress = $client.savedProgress || {};
                $client.savedProgress[$session.currentList] = {
                    currentIndex: $session.currentIndex,
                    hasSkippedItems: $session.hasSkippedItems
                };
            }
        if: $session.currentIndex < $session.items.length
            a: Пропускаем. А {{$session.items[$session.currentIndex]}} с нами?
        elseif: $session.hasSkippedItems
            a: Это был последний пункт. Чеклист пройден, но остались пропущенные вещи. Проверь их на экране.
        else:
            a: Ура! Все вещи из чеклиста успешно собраны. Счастливого пути!

    # --- Сброс текущего чеклиста без возврата на главную ---
    state: RestartCurrentChecklist
        
        q!: * (начни заново | сбрось чеклист | очисти список | давай сначала | начать сначала | сбрось | начни сначала) *
        event: CLICK_RESTART
        script:
            $session.currentIndex = 0; // Обнуляем индекс опроса на бэкенде
            $session.hasSkippedItems = false; // Сбрасываем флаг пропусков
            
            # СТИРАЕМ ДАННЫЕ ИЗ ДОЛГОСРОЧНОЙ ПАМЯТИ БЭКЕНДА ДЛЯ ЭТОГО СПИСКА
            $client.savedProgress = $client.savedProgress || {};
            if ($session.currentList) {
                $client.savedProgress[$session.currentList] = undefined;
            }

            // Проверяем, какой список сейчас активен, и перезапускаем его
            if ($session.currentList === "sea") {
                $session.items = ["Паспорт", "Купальник или плавки", "Солнцезащитный крем", "Солнцезащитные очки", "Шлепанцы"];
                resetChecklistAction($session.currentList, $session.items, $context);
                $reactions.answer("Сбрасываю список. Начнем сначала! Паспорт с тобой?");
            } else if ($session.currentList === "mountains") {
                $session.items = ["Паспорт", "Трекинговые ботинки", "Ветрозащитная куртка", "Фонарик", "Дождевик"];
                resetChecklistAction($session.currentList, $session.items, $context);
                $reactions.answer("Сбрасываю список. Начнем сначала! Паспорт при себе?");
            } else if ($session.currentList === "business") {
                $session.items = ["Паспорт", "Ноутбук", "Зарядное устройство", "Деловая одежда", "Блокнот и ручка"];
                resetChecklistAction($session.currentList, $session.items, $context);
                $reactions.answer("Сбрасываю список. Начнем сначала! Паспорт на месте?");
            } else {
                // Если вдруг список потерялся, отправляем на главную
                initApp($context);
                $reactions.answer("Не удалось определить текущий чеклист. Выбери направление: «На море», «В горы» или «Командировка»?");
            }

    state: ConfirmReset
        a: Мы уже проходились по этому списку. Взгляни на экран, чтобы проверить, не осталось ли чего-то важного. А если хочешь начать с чистого листа — скажи «Начни сначала».
        
        # Ожидаем согласие
        state: Agree
            q: * (начни заново | сбрось чеклист | очисти список | давай сначала | начать сначала | сбрось | начни сначала) *
            script:
                // Обнуляем индексы в сессии
                $session.currentIndex = 0;
                $session.hasSkippedItems = false;
                
                // Перезаписываем прогресс на бэкенде
                $client.savedProgress[$session.currentList] = {
                    currentIndex: 0,
                    hasSkippedItems: false
                };
                
                // Даем команду React-приложению очистить галочки
                resetChecklistAction($session.currentList, $session.items, $context);               
                // Проверяем, какой список сейчас активен, и перезапускаем его
                if ($session.currentList === "sea") {
                    $session.items = ["Паспорт", "Купальник или плавки", "Солнцезащитный крем", "Солнцезащитные очки", "Шлепанцы"];
                    resetChecklistAction($session.currentList, $session.items, $context);
                    $reactions.answer("Сбрасываю список. Начнем сначала! Паспорт с тобой?");
                } else if ($session.currentList === "mountains") {
                    $session.items = ["Паспорт", "Трекинговые ботинки", "Ветрозащитная куртка", "Фонарик", "Дождевик"];
                    resetChecklistAction($session.currentList, $session.items, $context);
                    $reactions.answer("Сбрасываю список. Начнем сначала! Паспорт при себе?");
                } else if ($session.currentList === "business") {
                    $session.items = ["Паспорт", "Ноутбук", "Зарядное устройство", "Деловая одежда", "Блокнот и ручка"];
                    resetChecklistAction($session.currentList, $session.items, $context);
                    $reactions.answer("Сбрасываю список. Начнем сначала! Паспорт на месте?");
                } else {
                    // Если вдруг список потерялся, отправляем на главную
                    initApp($context);
                    $reactions.answer("Не удалось определить текущий чеклист. Выбери направление: «На море», «В горы» или «Командировка»?");
                }
    