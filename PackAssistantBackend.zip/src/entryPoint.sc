require: slotfilling/slotFilling.sc
  module = sys.zb-common
  
# Подключение JavaScript обработчиков
require: js/getters.js
require: js/reply.js
require: js/actions.js

# Подключение логики чеклистов
require: sc/checklist.sc

patterns:
    $AnyText = $nonEmptyGarbage

theme: /
    state: Start
        # Срабатывает при старте через кнопку или по голосу
        q!: $regex</start>
        q!: (запусти | открой | включи) (PackAssistant | пак ассистент | pac ассистента | pac ассистент | помощник сборов | помощника сборов | помощник для сборов | помощника для сборов | дорожный чек лист | чек лист для поездки)
        script:
            # Очищаем сохраненный прогресс всех чеклистов при новом запуске
            $client.savedProgress = {};
            
            initApp($context);
            # Проверяем, заходил ли пользователь раньше
            if (!$client.isReturningUser) {
                
                # ---- ЛОГИКА ДЛЯ НОВИЧКА ----                
                $client.isReturningUser = true;
                $reactions.answer("Привет! Я твой голосовой помощник PackAssistant. Помогу собраться в поездку без лишней суеты. Выбери чеклист: «На море», «В горы» или «Командировка»?");
            
            } else {
                
                # ---- ЛОГИКА ДЛЯ ВЕРНУВШЕГОСЯ ПОЛЬЗОВАТЕЛЯ
                $reactions.answer("Привет! Куда отправляемся на этот раз? Выбери чеклист: «На море», «В горы» или «Командировка»?");
            
            }
        

    state: Fallback
        event!: noMatch
        script:
            // Если чеклист выбран
            if ($session.currentList) {
                $reactions.answer("Извини, не удалось распознать команду. Положить или пропустить?");
            } 
            // Если чеклист не выбран 
            else {
                $reactions.answer("Извини, я не понимаю. Выбери нужный чеклист из представленных на экране.");
            } 
    
    state: GoToMain
        q!: (новый чеклист | другая поездка | в начало | верни в начало | перезапусти | вернись в начало)
        event: GO_HOME
        a: Хорошо, возвращаемся в начало.
        script:
            $session = {}; // Jчищаем память ассистента о текущем чеклисте
            addAction({type: "INIT_APP"}, $context); // Отправляем команду в React
    

    state: Help
        q!: * (помощь|помоги|что ты умеешь|справка|инструкция|как пользоваться) *
        intent!: /help
        script:
            if ($session.currentList) {
                $reactions.transition("/HelpChecklist");
            } else {
                $reactions.transition("/HelpMain");
            }

    state: HelpChecklist
        script:      
        
            $reactions.answer("💡 Скажи «Да» или «Пропусти»");
            
            $response.replies[$response.replies.length - 1].tts = "Мы сейчас идем по списку вещей. Когда я называю предмет, скажи «Да» или нажми на чекбокс, если вещь уже в сумке. А если хочешь оставить вещь на потом, скажи «Пропусти» или нажми на оранжевую кнопку «Отложить».";

        
    state: HelpMain
        script:
            
            $reactions.answer("💡 Выбери направление поездки");            
            
            $response.replies[$response.replies.length - 1].tts = "Я помогаю собирать вещи в поездку без лишней суеты. Сейчас мы на главном экране. Чтобы начать, выбери направление: на море, в горы или в командировку. Назови нужный чеклист голосом или нажми на карточку на экране.";
       