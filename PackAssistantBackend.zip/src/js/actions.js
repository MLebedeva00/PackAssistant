function initApp(context) {
    addAction({
        type: "INIT_APP"
    }, context);
}

function setChecklistAction(listType, items, context) {
    // Берем индекс прямо из сессии, чтобы фронт знал, на чем мы остановились
    var currentIndex = context.session.currentIndex || 0; 
    
    addAction({
        type: "SET_CHECKLIST",
        listType: listType,
        items: items,
        backendIndex: currentIndex 
    }, context);
}

function updateItemStatusAction(index, status, context) {
    addAction({
        type: "UPDATE_ITEM_STATUS",
        index: index,
        status: status
    }, context);
}

function resetChecklistAction(listType, items, context) {
    addAction({
        type: "RESET_CHECKLIST",
        listType: listType,
        items: items
    }, context);
}